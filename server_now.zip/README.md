# VoiceRecordTranscriptor

Audio transcription service with speaker diarization using Whisper and GPU acceleration.

## Features

- Audio transcription using faster-whisper with GPU support
- Speaker diarization (multiple speaker detection)
- Web UI and REST API
- Background job queue (Redis)
- Docker deployment with NVIDIA GPU support
- Subtitle generation (SRT, VTT)
- Real-time progress tracking

## Quick Start

1. Set your auth token in `.env` file
2. Start services: `docker compose up -d`
3. Access UI: `https://localhost:8443/?token=your_token`

## Configuration

See `SYSTEM_NOTES.txt` for detailed configuration, GPU settings, and troubleshooting.

## Requirements

- Docker with NVIDIA GPU support
- NVIDIA GPU with CUDA support
- At least 8GB VRAM

## API Endpoints

- POST /api/upload - Upload audio file
- GET /api/jobs - List all jobs
- GET /api/diagnostics - System diagnostics
- GET /api/selftest - Quick GPU test

See SYSTEM_NOTES.txt for complete documentation.
